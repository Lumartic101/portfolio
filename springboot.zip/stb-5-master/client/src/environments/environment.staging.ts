export const environment = {
  production: false,
  apiUrl: 'https://stb-5-be-app-staging.herokuapp.com',
  environmentName: 'staging',
};
