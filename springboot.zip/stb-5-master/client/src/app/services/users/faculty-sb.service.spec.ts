// import { TestBed } from '@angular/core/testing';
//
// import { FacultySbService } from './faculty-sb.service';
//
// describe('FacultySbService', () => {
//   let service: FacultySbService;
//
//   beforeEach(() => {
//     TestBed.configureTestingModule({});
//     service = TestBed.inject(FacultySbService);
//   });
//
//   it('should be created', () => {
//     expect(service).toBeTruthy();
//   });
// });
