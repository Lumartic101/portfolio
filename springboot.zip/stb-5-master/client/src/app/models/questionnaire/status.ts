
export enum Status {
  OPEN = 'OPEN',
  CLOSED = 'CLOSED',
  CONCEPT = 'CONCEPT'
}
