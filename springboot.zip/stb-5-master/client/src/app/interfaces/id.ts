export interface Id {
  id: number
}
