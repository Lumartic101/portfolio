package nl.hva.stb5.backend.views;

public class PillarView {
    public interface base { }
    public interface getView { }
}
