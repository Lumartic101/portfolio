package nl.hva.stb5.backend.views;

public class EducationView {
    public interface base {}
}
