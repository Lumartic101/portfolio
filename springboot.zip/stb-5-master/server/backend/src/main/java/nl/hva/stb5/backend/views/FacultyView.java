package nl.hva.stb5.backend.views;

public class FacultyView {
    public interface base {}
}
