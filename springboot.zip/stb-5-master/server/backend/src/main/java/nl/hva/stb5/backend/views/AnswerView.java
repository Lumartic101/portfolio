package nl.hva.stb5.backend.views;

public class AnswerView {
    public interface base { }
    public interface submission { }
}
