package com.atos.msafe.model

data class NewUser(
    val emailAddress: String,
    val password: String
)
